import React, { useState, useEffect } from 'react';
import { Landing } from './components/Landing';
import { DataConfig } from './components/DataConfig';
import { ChartBuilder } from './components/ChartBuilder';
import { Dashboard } from './components/Dashboard';
import { processFile } from './utils/fileParser';
import { DataModel, ChartConfig, DataTable, SavedDashboard } from './types';
import { AlertCircle, CheckCircle2, X } from 'lucide-react';

enum Step {
  LANDING = 0,
  CONFIG = 1,
  BUILDER = 2,
  DASHBOARD = 3
}

interface ToastState {
  show: boolean;
  message: string;
  type: 'success' | 'error';
}

export default function App() {
  const [step, setStep] = useState<Step>(Step.LANDING);
  const [initialTables, setInitialTables] = useState<DataTable[]>([]);
  const [fileName, setFileName] = useState('');
  const [dataModel, setDataModel] = useState<DataModel | null>(null);
  const [chartConfigs, setChartConfigs] = useState<ChartConfig[]>([]);
  
  // UI State
  const [toast, setToast] = useState<ToastState>({ show: false, message: '', type: 'success' });
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  
  // Saved Dashboards State
  const [savedDashboards, setSavedDashboards] = useState<SavedDashboard[]>([]);

  // Load saved dashboards from local storage on init
  useEffect(() => {
    const saved = localStorage.getItem('insightAI_dashboards');
    if (saved) {
        try {
            setSavedDashboards(JSON.parse(saved));
        } catch (e) {
            console.error("Failed to load saved dashboards", e);
        }
    }
  }, []);

  // Reset scroll position when changing steps
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [step]);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), 3000);
  };

  const handleFileUpload = async (file: File) => {
    try {
      const tables = await processFile(file);
      setInitialTables(tables);
      setFileName(file.name);
      setStep(Step.CONFIG);
    } catch (error) {
      console.error("File processing failed", error);
      showToast("Failed to process file. Please ensure it is a valid CSV or Excel file.", 'error');
    }
  };

  const handleConfigFinalize = (model: DataModel) => {
    setDataModel(model);
    setStep(Step.BUILDER);
  };

  const handleGenerateReport = (charts: ChartConfig[]) => {
    setChartConfigs(charts);
    setStep(Step.DASHBOARD);
  };

  const handleReturnHomeRequest = () => {
    setShowExitConfirm(true);
  };

  const confirmReturnHome = () => {
    setShowExitConfirm(false);
    setStep(Step.LANDING);
    setInitialTables([]);
    setFileName('');
    setDataModel(null);
    setChartConfigs([]);
  };

  const handleSaveDashboard = (name: string, currentCharts: ChartConfig[]) => {
    if (!dataModel) return;

    const newDash: SavedDashboard = {
        id: Date.now().toString(),
        name,
        date: new Date().toLocaleDateString(),
        dataModel: dataModel,
        chartConfigs: currentCharts
    };

    const updatedDashboards = [newDash, ...savedDashboards];
    setSavedDashboards(updatedDashboards);
    localStorage.setItem('insightAI_dashboards', JSON.stringify(updatedDashboards));
    showToast(`Dashboard "${name}" saved successfully!`, 'success');
  };

  const handleLoadDashboard = (dash: SavedDashboard) => {
    setDataModel(dash.dataModel);
    setChartConfigs(dash.chartConfigs);
    setStep(Step.DASHBOARD);
  };

  const handleDeleteDashboard = (id: string) => {
    if (window.confirm("Are you sure you want to delete this dashboard?")) {
        const updated = savedDashboards.filter(d => d.id !== id);
        setSavedDashboards(updated);
        localStorage.setItem('insightAI_dashboards', JSON.stringify(updated));
        showToast("Dashboard deleted.", 'success');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 relative selection:bg-indigo-500/30">
      {/* Toast Notification */}
      <div className={`fixed top-6 right-6 z-[100] transition-all duration-300 transform ${toast.show ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0 pointer-events-none'}`}>
        <div className={`flex items-center gap-3 px-6 py-4 rounded-xl shadow-2xl border ${toast.type === 'success' ? 'bg-slate-900 border-emerald-500/50 text-emerald-400' : 'bg-slate-900 border-red-500/50 text-red-400'}`}>
          {toast.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          <span className="font-medium text-white">{toast.message}</span>
        </div>
      </div>

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 max-w-md w-full shadow-2xl transform scale-100">
            <h3 className="text-xl font-bold text-white mb-2">Return to Home?</h3>
            <p className="text-slate-400 mb-6">
              Any unsaved progress in your current analysis will be lost. Are you sure you want to leave?
            </p>
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setShowExitConfirm(false)}
                className="px-4 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
              >
                Cancel
              </button>
              <button 
                onClick={confirmReturnHome}
                className="px-6 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white font-medium transition shadow-lg shadow-red-900/20"
              >
                Yes, Leave
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fixed Background Ambience */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-0 left-0 w-full h-96 bg-indigo-900/20 blur-[120px] rounded-full -translate-y-1/2"></div>
          <div className="absolute bottom-0 right-0 w-full h-96 bg-violet-900/20 blur-[120px] rounded-full translate-y-1/2"></div>
      </div>
      
      <div className="relative z-10 min-h-screen flex flex-col">
        {step === Step.LANDING && (
            <Landing 
                onFileUpload={handleFileUpload} 
                savedDashboards={savedDashboards}
                onLoadDashboard={handleLoadDashboard}
                onDeleteDashboard={handleDeleteDashboard}
            />
        )}
        
        {step === Step.CONFIG && initialTables.length > 0 && (
          <DataConfig 
              initialTables={initialTables} 
              fileName={fileName} 
              onFinalize={handleConfigFinalize} 
              onHome={handleReturnHomeRequest}
          />
        )}

        {step === Step.BUILDER && dataModel && (
          <ChartBuilder 
              dataModel={dataModel} 
              onGenerateReport={handleGenerateReport} 
              onHome={handleReturnHomeRequest}
          />
        )}

        {step === Step.DASHBOARD && dataModel && (
          <Dashboard 
              dataModel={dataModel} 
              chartConfigs={chartConfigs} 
              onHome={handleReturnHomeRequest} 
              onSave={handleSaveDashboard}
          />
        )}
      </div>
    </div>
  );
}