import React, { useState, useEffect } from 'react';
import { DataModel, ChartConfig } from '../types';
import { analyzeDataAndSuggestKPIs, generateChartFromPrompt } from '../services/geminiService';
import { Plus, Sparkles, X, BarChart3, PieChart, LineChart, Activity, Send, Loader2, ArrowRight, Table as TableIcon, Mic, MicOff, Home, Save } from 'lucide-react';

interface ChartBuilderProps {
  dataModel: DataModel;
  onGenerateReport: (charts: ChartConfig[]) => void;
  onHome: () => void;
  initialBucket?: ChartConfig[];
  mode?: 'create' | 'update';
}

export const ChartBuilder: React.FC<ChartBuilderProps> = ({ 
  dataModel, 
  onGenerateReport, 
  onHome, 
  initialBucket = [], 
  mode = 'create' 
}) => {
  const [suggestedCharts, setSuggestedCharts] = useState<ChartConfig[]>([]);
  const [bucket, setBucket] = useState<ChartConfig[]>(initialBucket);
  const [loading, setLoading] = useState(true);
  const [customPrompt, setCustomPrompt] = useState('');
  const [isGeneratingCustom, setIsGeneratingCustom] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showData, setShowData] = useState(false);

  useEffect(() => {
    if (initialBucket && initialBucket.length > 0) {
        setBucket(initialBucket);
    }
  }, [initialBucket]);

  useEffect(() => {
    const fetchSuggestions = async () => {
      setLoading(true);
      const suggestions = await analyzeDataAndSuggestKPIs(dataModel);
      setSuggestedCharts(suggestions);
      setLoading(false);
    };
    fetchSuggestions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataModel.name]);

  const addToBucket = (chart: ChartConfig) => {
    if (!bucket.find(c => c.id === chart.id)) {
      setBucket([...bucket, chart]);
    }
  };

  const removeFromBucket = (id: string) => {
    setBucket(bucket.filter(c => c.id !== id));
  };

  const handleCustomChart = async () => {
    if (!customPrompt.trim()) return;
    setIsGeneratingCustom(true);
    const newChart = await generateChartFromPrompt(dataModel, customPrompt);
    if (newChart) {
      setBucket([newChart, ...bucket]);
      setCustomPrompt('');
    }
    setIsGeneratingCustom(false);
  };

  const toggleVoiceInput = () => {
    if (isListening) {
        setIsListening(false);
        return;
    }

    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert("Voice recognition is not supported in this browser. Please use Chrome.");
        return;
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    
    recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setCustomPrompt(prev => (prev ? prev + ' ' + transcript : transcript));
        setIsListening(false);
    };

    recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event);
        setIsListening(false);
    };

    recognition.onend = () => setIsListening(false);

    recognition.start();
  };

  const getIcon = (type: string) => {
    switch(type) {
      case 'BAR': return <BarChart3 className="w-5 h-5" />;
      case 'PIE': return <PieChart className="w-5 h-5" />;
      case 'LINE': return <LineChart className="w-5 h-5" />;
      case 'AREA': return <Activity className="w-5 h-5" />;
      case 'KPI': return <div className="text-xs font-bold border border-current px-1 rounded">123</div>;
      default: return <BarChart3 className="w-5 h-5" />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden relative">
        {/* Data Preview Modal */}
        {showData && (
            <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-4 lg:p-12 animate-fade-in">
                <div className="bg-slate-900 border border-slate-800 w-full h-full rounded-2xl flex flex-col shadow-2xl overflow-hidden">
                    <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900">
                        <div>
                            <h2 className="font-bold text-white text-xl">Dataset Preview</h2>
                            <p className="text-slate-500 text-sm">{dataModel.data.length} rows found</p>
                        </div>
                        <button onClick={() => setShowData(false)} className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition">
                            <X className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="flex-1 overflow-auto p-0">
                        <table className="w-full text-left text-sm text-slate-400">
                            <thead className="bg-slate-800/80 sticky top-0 z-10 backdrop-blur-sm">
                                <tr>{dataModel.columns.map(c => <th key={c} className="px-6 py-3 font-semibold text-white border-b border-slate-700 whitespace-nowrap">{c}</th>)}</tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800">
                                {dataModel.data.slice(0, 200).map((row, i) => (
                                    <tr key={i} className="hover:bg-slate-800/50 transition-colors">
                                        {dataModel.columns.map(c => (
                                            <td key={c} className="px-6 py-3 whitespace-nowrap max-w-[200px] overflow-hidden text-ellipsis">
                                                {row[c] !== null && row[c] !== undefined ? String(row[c]) : <span className="text-slate-700 italic">null</span>}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="p-4 border-t border-slate-800 bg-slate-900 text-center text-xs text-slate-500">
                        Showing first 200 rows for preview
                    </div>
                </div>
            </div>
        )}

        {/* Left: AI Suggestions */}
        <div className="w-[350px] lg:w-[400px] border-r border-slate-800 bg-slate-900 flex flex-col z-10 shadow-2xl shrink-0">
            <div className="p-6 border-b border-slate-800 bg-slate-900">
                <div className="flex items-center gap-3 mb-2">
                    <button onClick={onHome} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition" title={mode === 'update' ? "Cancel" : "Go Home"}>
                        {mode === 'update' ? <X className="w-4 h-4" /> : <Home className="w-4 h-4" />}
                    </button>
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                        <Sparkles className="text-indigo-400 w-5 h-5" />
                        Insights
                    </h2>
                </div>
                <p className="text-xs text-slate-400 ml-8">
                    AI suggestions based on <span className="text-slate-300 font-medium">{dataModel.name}</span>
                </p>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                {loading ? (
                    <div className="flex flex-col items-center justify-center h-64 gap-4">
                        <div className="relative">
                            <div className="w-10 h-10 rounded-full border-2 border-indigo-500/20 border-t-indigo-500 animate-spin"></div>
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></div>
                            </div>
                        </div>
                        <p className="text-slate-500 text-xs animate-pulse">Consulting Gemini...</p>
                    </div>
                ) : (
                    suggestedCharts.map(chart => {
                        const inBucket = !!bucket.find(b => b.id === chart.id);
                        return (
                            <div 
                                key={chart.id} 
                                className={`group relative rounded-xl p-5 transition-all duration-300 border
                                    ${inBucket 
                                        ? 'bg-indigo-900/10 border-indigo-500/30 opacity-60' 
                                        : 'bg-slate-800/50 border-slate-700 hover:border-indigo-500/50 hover:bg-slate-800 hover:shadow-lg hover:shadow-indigo-500/10 hover:-translate-y-1'
                                    }
                                `}
                            >
                                <div className="flex justify-between items-start mb-3">
                                    <div className="flex items-center gap-2 text-indigo-400">
                                        {getIcon(chart.type)}
                                        <span className="text-[10px] font-bold uppercase tracking-wider bg-indigo-500/10 px-2 py-0.5 rounded text-indigo-300">
                                            {chart.type}
                                        </span>
                                    </div>
                                    {!inBucket && (
                                        <button 
                                            onClick={() => addToBucket(chart)}
                                            className="text-slate-400 hover:text-white bg-slate-700 hover:bg-indigo-500 p-1.5 rounded-lg transition-colors"
                                        >
                                            <Plus className="w-4 h-4" />
                                        </button>
                                    )}
                                </div>
                                <h3 className="font-bold text-slate-200 text-sm leading-snug">{chart.title}</h3>
                                <p className="text-xs text-slate-500 mt-2 leading-relaxed line-clamp-2">{chart.description}</p>
                            </div>
                        )
                    })
                )}
            </div>
        </div>

        {/* Right: Workspace */}
        <div className="flex-1 flex flex-col relative">
            {/* Header */}
            <header className="px-8 py-6 flex justify-between items-center z-20 pointer-events-none bg-gradient-to-b from-slate-950 to-slate-950/0">
                <div className="flex items-center gap-4 pointer-events-auto">
                    <h1 className="text-2xl font-bold text-white">
                        {mode === 'update' ? 'Edit Dashboard' : 'Chart Builder'}
                    </h1>
                    <button 
                        onClick={() => setShowData(true)}
                        className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md text-xs font-medium text-slate-300 transition"
                    >
                        <TableIcon className="w-3 h-3" /> View Data
                    </button>
                </div>
                <button 
                    onClick={() => onGenerateReport(bucket)}
                    disabled={bucket.length === 0}
                    className="pointer-events-auto bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 disabled:from-slate-700 disabled:to-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed text-white px-6 py-2.5 rounded-full font-bold text-sm transition-all flex items-center gap-2 shadow-lg shadow-emerald-900/20 active:scale-95"
                >
                    {mode === 'update' ? (
                        <>Save Updates <Save className="w-4 h-4" /></>
                    ) : (
                        <>Generate Report <ArrowRight className="w-4 h-4" /></>
                    )}
                </button>
            </header>

            <div className="flex-1 p-8 pt-0 overflow-y-auto custom-scrollbar flex flex-col gap-8">
                
                {/* AI Chat Input */}
                <div className="w-full max-w-3xl mx-auto mt-4">
                    <div className="relative group">
                        <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-500"></div>
                        <div className="relative bg-slate-900 rounded-2xl p-1 flex items-center ring-1 ring-white/10 focus-within:ring-indigo-500/50 transition-all">
                            <input 
                                type="text"
                                value={customPrompt}
                                onChange={(e) => setCustomPrompt(e.target.value)}
                                placeholder="Ask for a custom chart (e.g., 'Show average sales by region as a pie chart')"
                                className="flex-1 bg-transparent border-none text-slate-200 placeholder-slate-500 px-5 py-3 focus:ring-0 outline-none text-sm"
                                onKeyDown={(e) => e.key === 'Enter' && handleCustomChart()}
                            />
                            <div className="flex items-center gap-1 pr-1">
                                <button 
                                    onClick={toggleVoiceInput}
                                    className={`p-2.5 rounded-xl transition ${isListening ? 'bg-red-500 text-white animate-pulse' : 'hover:bg-slate-800 text-slate-400'}`}
                                    title="Use Voice Input"
                                >
                                    {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                                </button>
                                <button 
                                    onClick={handleCustomChart}
                                    disabled={isGeneratingCustom || !customPrompt.trim()}
                                    className="bg-indigo-600 hover:bg-indigo-500 text-white p-2.5 rounded-xl transition disabled:opacity-50 disabled:bg-slate-700"
                                >
                                    {isGeneratingCustom ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                                </button>
                            </div>
                        </div>
                    </div>
                    {isListening && (
                        <p className="text-center text-xs text-indigo-400 mt-2 animate-pulse">Listening...</p>
                    )}
                </div>

                {/* The Bucket Area */}
                <div className="flex-1">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="h-px flex-1 bg-slate-800"></div>
                        <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider">
                            {mode === 'update' ? 'Dashboard Charts' : 'Your Selection'}
                        </h3>
                        <div className="h-px flex-1 bg-slate-800"></div>
                    </div>
                    
                    {bucket.length === 0 ? (
                        <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-2xl bg-slate-900/30">
                            <div className="bg-slate-800 p-4 rounded-full mb-4">
                                <BarChart3 className="text-slate-600 w-8 h-8" />
                            </div>
                            <p className="text-slate-400 font-medium">Your dashboard bucket is empty</p>
                            <p className="text-slate-600 text-xs mt-2">Select insights from the left or ask AI above.</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 pb-20">
                            {bucket.map((chart, i) => (
                                <div 
                                    key={chart.id} 
                                    className="bg-slate-900 border border-slate-800 rounded-xl p-5 relative group hover:border-indigo-500/30 hover:shadow-xl hover:shadow-indigo-900/10 transition-all duration-300 animate-fade-in-up"
                                    style={{ animationDelay: `${i * 50}ms` }}
                                >
                                    <button 
                                        onClick={() => removeFromBucket(chart.id)}
                                        className="absolute top-3 right-3 text-slate-500 hover:text-red-400 hover:bg-red-400/10 p-1.5 rounded-md transition opacity-0 group-hover:opacity-100"
                                    >
                                        <X className="w-4 h-4" />
                                    </button>
                                    
                                    <div className="flex items-center gap-2 mb-4">
                                         <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${chart.id.startsWith('custom') ? 'bg-emerald-500/10 text-emerald-400' : 'bg-indigo-500/10 text-indigo-400'}`}>
                                            {getIcon(chart.type)}
                                         </div>
                                         <div>
                                            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                                                {chart.id.startsWith('custom') ? 'Custom Request' : 'AI Insight'}
                                            </div>
                                            <h4 className="font-bold text-slate-200 text-sm truncate w-48">{chart.title}</h4>
                                         </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-3 gap-2 py-3 border-t border-slate-800/50">
                                        <div className="text-center p-2 bg-slate-950/50 rounded-lg">
                                            <div className="text-[10px] text-slate-500 uppercase">X-Axis</div>
                                            <div className="text-xs text-slate-300 font-mono mt-1 truncate">{chart.xAxisKey || "-"}</div>
                                        </div>
                                        <div className="text-center p-2 bg-slate-950/50 rounded-lg">
                                            <div className="text-[10px] text-slate-500 uppercase">Metric</div>
                                            <div className="text-xs text-slate-300 font-mono mt-1 truncate">{chart.dataKey}</div>
                                        </div>
                                        <div className="text-center p-2 bg-slate-950/50 rounded-lg">
                                            <div className="text-[10px] text-slate-500 uppercase">Agg</div>
                                            <div className="text-xs text-slate-300 font-mono mt-1 truncate">{chart.aggregation}</div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    </div>
  );
};