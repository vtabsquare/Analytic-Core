import React, { useMemo, useState, useEffect } from 'react';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, AreaChart, Area, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, Brush
} from 'recharts';
import { DataModel, ChartConfig, ChartType } from '../types';
import { aggregateData } from '../utils/aggregator';
import { LayoutDashboard, Download, Share2, TrendingUp, Loader2, Maximize2, X, Home, Save, Edit } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { ChartBuilder } from './ChartBuilder';

interface DashboardProps {
  dataModel: DataModel;
  chartConfigs: ChartConfig[];
  onHome: () => void;
  onSave: (name: string, charts: ChartConfig[]) => void;
}

// Vibrant dark mode palette
const COLORS = ['#6366f1', '#10b981', '#f43f5e', '#f59e0b', '#8b5cf6', '#06b6d4'];

const RenderChart = ({ config, data, isExpanded = false }: { config: ChartConfig, data: any[], isExpanded?: boolean }) => {
  if (!data || data.length === 0) return <div className="flex items-center justify-center h-full text-slate-500 text-sm">No Data Available</div>;

  const commonProps = {
    data: data,
    margin: { top: 10, right: 30, left: 0, bottom: 0 }
  };

  const AxisProps = {
    axisLine: false,
    tickLine: false,
    tick: { fontSize: 11, fill: '#64748b' },
    dy: 10,
    minTickGap: 30,
    tickFormatter: (val: any) => {
        const str = String(val);
        if (str.length > 12) return str.substring(0, 10) + '..';
        return str;
    }
  };

  const TooltipProps = {
    contentStyle: { backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9', borderRadius: '8px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)' },
    itemStyle: { color: '#e2e8f0' },
    cursor: { fill: '#334155', opacity: 0.4 }
  };

  const showBrush = data.length > 15;

  switch (config.type) {
    case ChartType.BAR:
      return (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
            <XAxis dataKey={config.xAxisKey} {...AxisProps} />
            <YAxis {...AxisProps} />
            <Tooltip {...TooltipProps} />
            <Bar dataKey={config.dataKey} fill={COLORS[0]} radius={[4, 4, 0, 0]} />
            {showBrush && (
                <Brush 
                    dataKey={config.xAxisKey} 
                    height={30} 
                    stroke="#6366f1" 
                    fill="#1e293b" 
                    tickFormatter={() => ''}
                />
            )}
          </BarChart>
        </ResponsiveContainer>
      );
    case ChartType.LINE:
      return (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
            <XAxis dataKey={config.xAxisKey} {...AxisProps} />
            <YAxis {...AxisProps} />
            <Tooltip {...TooltipProps} />
            <Line 
                type="monotone" 
                dataKey={config.dataKey} 
                stroke={COLORS[1]} 
                strokeWidth={3} 
                dot={data.length > 50 ? false : {fill: '#0f172a', stroke: COLORS[1], strokeWidth: 2, r: 4}} 
                activeDot={{r: 6, fill: COLORS[1]}} 
            />
            {showBrush && (
                <Brush 
                    dataKey={config.xAxisKey} 
                    height={30} 
                    stroke="#6366f1" 
                    fill="#1e293b" 
                    tickFormatter={() => ''}
                />
            )}
          </LineChart>
        </ResponsiveContainer>
      );
    case ChartType.AREA:
        return (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart {...commonProps}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
              <XAxis dataKey={config.xAxisKey} {...AxisProps} />
              <YAxis {...AxisProps} />
              <Tooltip {...TooltipProps} />
              <defs>
                <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS[4]} stopOpacity={0.4}/>
                  <stop offset="95%" stopColor={COLORS[4]} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Area type="monotone" dataKey={config.dataKey} stroke={COLORS[4]} fill="url(#colorGradient)" strokeWidth={2} />
              {showBrush && (
                <Brush 
                    dataKey={config.xAxisKey} 
                    height={30} 
                    stroke="#6366f1" 
                    fill="#1e293b" 
                    tickFormatter={() => ''}
                />
              )}
            </AreaChart>
          </ResponsiveContainer>
        );
    case ChartType.PIE:
      return (
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={isExpanded ? 120 : 60}
              outerRadius={isExpanded ? 160 : 80}
              paddingAngle={5}
              dataKey={config.dataKey}
              nameKey={config.xAxisKey}
              stroke="none"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip {...TooltipProps} />
            <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{fontSize: '12px', color: '#94a3b8'}} />
          </PieChart>
        </ResponsiveContainer>
      );
    default:
      return null;
  }
};

export const Dashboard: React.FC<DashboardProps> = ({ dataModel, chartConfigs, onHome, onSave }) => {
  // Local state for charts allows editing/adding charts in-place
  const [currentCharts, setCurrentCharts] = useState<ChartConfig[]>(chartConfigs);
  const [isEditing, setIsEditing] = useState(false);
  
  // UI State
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [dashboardName, setDashboardName] = useState(dataModel.name);

  // Update local state if props change (e.g. loading a new dashboard)
  useEffect(() => {
      setCurrentCharts(chartConfigs);
      setDashboardName(dataModel.name);
  }, [chartConfigs, dataModel.name]);

  const kpis = useMemo(() => currentCharts.filter(c => c.type === ChartType.KPI), [currentCharts]);
  const charts = useMemo(() => currentCharts.filter(c => c.type !== ChartType.KPI), [currentCharts]);
  
  const [isExporting, setIsExporting] = useState(false);
  const [expandedChartId, setExpandedChartId] = useState<string | null>(null);

  const expandedChartConfig = useMemo(() => 
    currentCharts.find(c => c.id === expandedChartId), 
  [expandedChartId, currentCharts]);

  const handleExportPDF = async () => {
    setIsExporting(true);
    await new Promise(resolve => setTimeout(resolve, 50));

    try {
        const element = document.getElementById('dashboard-container');
        if (!element) throw new Error("Dashboard container not found");

        const canvas = await html2canvas(element, {
            scale: 2,
            backgroundColor: '#0f172a',
            useCORS: true,
            logging: false,
            ignoreElements: (node) => node.classList.contains('no-export') || node.classList.contains('chart-controls')
        });

        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'px',
            format: [canvas.width, canvas.height]
        });

        pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
        pdf.save(`${dataModel.name.replace(/\s+/g, '_')}_Dashboard.pdf`);

    } catch (error) {
        console.error("Export PDF Error:", error);
        alert("Failed to generate PDF. Please try using the browser Print function.");
    } finally {
        setIsExporting(false);
    }
  };

  const openSaveModal = () => {
      setDashboardName(dataModel.name);
      setIsSaveModalOpen(true);
  };

  const handleSaveConfirm = () => {
      if (!dashboardName.trim()) {
          alert("Please enter a valid name");
          return;
      }
      onSave(dashboardName, currentCharts);
      setIsSaveModalOpen(false);
  };

  const handleUpdateFromBuilder = (updatedCharts: ChartConfig[]) => {
    setCurrentCharts(updatedCharts);
    setIsEditing(false);
  };

  return (
    <>
        {/* Save Dashboard Modal */}
        {isSaveModalOpen && (
            <div className="fixed inset-0 z-[60] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 max-w-md w-full shadow-2xl">
                    <h3 className="text-xl font-bold text-white mb-4">Save Dashboard</h3>
                    <div className="mb-6">
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Dashboard Name</label>
                        <input 
                            type="text" 
                            value={dashboardName}
                            onChange={(e) => setDashboardName(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                            placeholder="Enter name..."
                            autoFocus
                        />
                    </div>
                    <div className="flex justify-end gap-3">
                        <button 
                            onClick={() => setIsSaveModalOpen(false)}
                            className="px-4 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={handleSaveConfirm}
                            className="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium transition shadow-lg shadow-indigo-900/20 flex items-center gap-2"
                        >
                            <Save className="w-4 h-4" /> Save Dashboard
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* Edit Mode Modal - Overlays the entire screen with ChartBuilder */}
        {isEditing && (
            <div className="fixed inset-0 z-50 bg-slate-950 animate-fade-in">
                <ChartBuilder 
                    dataModel={dataModel} 
                    onGenerateReport={handleUpdateFromBuilder}
                    onHome={() => setIsEditing(false)}
                    initialBucket={currentCharts}
                    mode="update"
                />
            </div>
        )}

        {/* Expanded Chart Modal */}
        {expandedChartConfig && (
            <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4 lg:p-8 animate-fade-in no-print">
                <div className="bg-slate-900 w-full h-full max-w-7xl max-h-[90vh] rounded-2xl border border-slate-800 shadow-2xl flex flex-col relative">
                    <div className="p-6 border-b border-slate-800 flex justify-between items-start">
                        <div>
                            <h2 className="text-2xl font-bold text-white">{expandedChartConfig.title}</h2>
                            <p className="text-slate-400 mt-1">{expandedChartConfig.description}</p>
                        </div>
                        <button 
                            onClick={() => setExpandedChartId(null)}
                            className="p-2 bg-slate-800 hover:bg-red-500/20 hover:text-red-500 rounded-lg transition-colors text-slate-400"
                        >
                            <X className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="flex-1 p-6 min-h-0">
                        <RenderChart 
                            config={expandedChartConfig} 
                            data={aggregateData(dataModel.data, expandedChartConfig)} 
                            isExpanded={true}
                        />
                    </div>
                    <div className="p-4 bg-slate-900 border-t border-slate-800 text-center">
                        <p className="text-xs text-slate-500">Use the slider below the chart to zoom into specific time periods or categories.</p>
                    </div>
                </div>
            </div>
        )}

        <div id="dashboard-container" className="min-h-screen bg-slate-950 flex flex-col text-slate-200 print:bg-slate-950">
        {/* Header */}
        <header className="bg-slate-900/80 backdrop-blur border-b border-slate-800 px-8 py-4 sticky top-0 z-30 shadow-lg print:hidden">
            <div className="flex justify-between items-center max-w-7xl mx-auto w-full">
                <div className="flex items-center gap-4">
                    <button onClick={onHome} className="p-2 -ml-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition no-export" title="Return Home">
                        <Home className="w-5 h-5" />
                    </button>
                    <div>
                        <h1 className="text-xl font-bold text-white flex items-center gap-2">
                            {dataModel.name} 
                            <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/20 uppercase tracking-wider">Live</span>
                        </h1>
                        <p className="text-xs text-slate-500">InsightAI Generated Report</p>
                    </div>
                </div>
                <div className="flex gap-3 no-export">
                    <button 
                        onClick={() => setIsEditing(true)}
                        className="flex items-center gap-2 text-slate-300 hover:text-white px-4 py-2 rounded-lg hover:bg-slate-800 transition font-medium text-sm border border-transparent hover:border-slate-700"
                    >
                        <Edit className="w-4 h-4" /> Edit / Add Charts
                    </button>
                    <button 
                        onClick={openSaveModal}
                        className="flex items-center gap-2 text-slate-300 hover:text-white px-4 py-2 rounded-lg hover:bg-slate-800 transition font-medium text-sm border border-transparent hover:border-slate-700"
                    >
                        <Save className="w-4 h-4" /> Save
                    </button>
                    <button className="flex items-center gap-2 text-slate-300 hover:text-white px-4 py-2 rounded-lg hover:bg-slate-800 transition font-medium text-sm border border-transparent hover:border-slate-700">
                        <Share2 className="w-4 h-4" /> Share
                    </button>
                    <button 
                        onClick={handleExportPDF}
                        disabled={isExporting}
                        className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 disabled:cursor-wait text-white px-4 py-2 rounded-lg transition font-medium text-sm shadow-lg shadow-indigo-900/20"
                    >
                        {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                        {isExporting ? 'Generating...' : 'Export PDF'}
                    </button>
                </div>
            </div>
        </header>

        {/* Print Header */}
        <div className="hidden print:block px-8 py-6 border-b border-slate-800 mb-6">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">{dataModel.name} Dashboard</h1>
            <p className="text-slate-500">Generated via InsightAI</p>
        </div>

        <main className="p-8 max-w-7xl mx-auto w-full print:p-4">
            
            {/* KPIs Row */}
            {kpis.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 print:grid-cols-4">
                    {kpis.map((kpi, i) => {
                        const data = aggregateData(dataModel.data, kpi);
                        return (
                            <div key={kpi.id} className="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow-xl relative overflow-hidden group print:shadow-none print:border-slate-600">
                                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition transform group-hover:scale-110 print:hidden">
                                    <TrendingUp className="w-16 h-16 text-indigo-500" />
                                </div>
                                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{kpi.title}</h3>
                                <div className="text-3xl font-bold text-white mt-2">
                                    {data[0]?.value?.toLocaleString() || 0}
                                </div>
                                <div className="mt-4 h-1 w-full bg-slate-800 rounded-full overflow-hidden print:bg-slate-700">
                                    <div className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 w-2/3 rounded-full print:bg-indigo-600"></div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 print:grid-cols-2 print:gap-4">
                {charts.map(chart => {
                    const aggregatedData = aggregateData(dataModel.data, chart);
                    return (
                        <div key={chart.id} className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-lg h-[420px] flex flex-col hover:border-slate-700 transition-colors print:shadow-none print:border-slate-600 print:break-inside-avoid relative group">
                            <div className="mb-6 pr-8">
                                <h3 className="font-bold text-lg text-slate-100 truncate">{chart.title}</h3>
                                <p className="text-xs text-slate-500 mt-1 truncate">{chart.description}</p>
                            </div>
                            
                            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity chart-controls no-print">
                                <button 
                                    onClick={() => setExpandedChartId(chart.id)}
                                    className="p-2 bg-slate-800 hover:bg-indigo-600 text-slate-400 hover:text-white rounded-lg transition-all shadow-lg"
                                    title="Maximize Chart"
                                >
                                    <Maximize2 className="w-4 h-4" />
                                </button>
                            </div>

                            <div className="flex-1 w-full min-h-0">
                                <RenderChart config={chart} data={aggregatedData} />
                            </div>
                        </div>
                    );
                })}
            </div>

            {charts.length === 0 && kpis.length === 0 && (
                <div className="text-center py-20 border-2 border-dashed border-slate-800 rounded-3xl bg-slate-900/50">
                    <LayoutDashboard className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-white">Empty Dashboard</h3>
                    <p className="text-slate-400 mt-2">Go back and select some charts to populate this view.</p>
                    <button onClick={() => setIsEditing(true)} className="mt-6 text-indigo-400 hover:underline">
                        Add Charts Now
                    </button>
                </div>
            )}
        </main>
        </div>
    </>
  );
};