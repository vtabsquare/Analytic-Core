import React, { useState, useEffect, useRef } from 'react';
import { DataModel, ProcessedRow, DataTable, JoinConfig, JoinType } from '../types';
import { ArrowRight, Table, CheckSquare, Square, Database, Columns, Plus, Link as LinkIcon, Trash2, Upload, Settings2, Home } from 'lucide-react';
import { processFile } from '../utils/fileParser';
import { performJoins, processRawData } from '../utils/dataProcessing';

interface DataConfigProps {
  initialTables: DataTable[];
  fileName: string;
  onFinalize: (model: DataModel) => void;
  onHome: () => void;
}

export const DataConfig: React.FC<DataConfigProps> = ({ initialTables, fileName, onFinalize, onHome }) => {
  // Tables State
  const [tables, setTables] = useState<DataTable[]>(initialTables);
  
  // Configuration State
  const [activeTab, setActiveTab] = useState<'JOIN' | 'COLUMNS'>('JOIN');
  const [joins, setJoins] = useState<JoinConfig[]>([]);
  const [headerIndices, setHeaderIndices] = useState<{[key: string]: number}>({});
  
  // Initialize header indices for all tables
  useEffect(() => {
     const indices: {[key: string]: number} = {};
     tables.forEach(t => {
         // Preserve existing indices if table already existed
         if (headerIndices[t.id] === undefined) {
             indices[t.id] = 0;
         } else {
             indices[t.id] = headerIndices[t.id];
         }
     });
     setHeaderIndices(indices);
  }, [tables]);

  // Result State
  const [mergedData, setMergedData] = useState<any[]>([]);
  const [mergedColumns, setMergedColumns] = useState<string[]>([]);
  const [selectedColumns, setSelectedColumns] = useState<Set<string>>(new Set());
  
  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Helper: Get columns for a specific table ---
  const getTableColumns = (tableId: string): string[] => {
    const table = tables.find(t => t.id === tableId);
    if (!table) return [];
    const idx = headerIndices[tableId] || 0;
    return table.rawData.rows[idx] || [];
  };

  const handleAddTable = async (file: File) => {
    try {
        const newTables = await processFile(file);
        setTables(prev => [...prev, ...newTables]);
    } catch (error) {
        console.error("Failed to add table", error);
        alert("Could not process file.");
    }
  };

  const addJoin = () => {
    if (tables.length < 2) return;
    // Default to joining the first two available tables
    const leftId = tables[0].id;
    const rightId = tables[1].id;
    
    const newJoin: JoinConfig = {
        id: String(Date.now()),
        leftTableId: leftId,
        rightTableId: rightId,
        leftKey: '',
        rightKey: '',
        type: JoinType.INNER
    };
    setJoins([...joins, newJoin]);
  };

  const removeJoin = (id: string) => {
    setJoins(joins.filter(j => j.id !== id));
  };

  const updateJoin = (id: string, field: keyof JoinConfig, value: string) => {
    setJoins(joins.map(j => j.id === id ? { ...j, [field]: value } : j));
  };

  // --- Effect: Calculate Merged Data ---
  useEffect(() => {
    // If no joins, just process the first table
    if (tables.length === 0) return;

    if (tables.length === 1 || joins.length === 0) {
        const t = tables[0];
        const res = processRawData(t.rawData, headerIndices[t.id] || 0);
        setMergedData(res.rows);
        setMergedColumns(res.headers);
    } else {
        // Perform Joins
        const result = performJoins(tables, joins, headerIndices);
        setMergedData(result.data);
        setMergedColumns(result.columns);
    }
  }, [tables, joins, headerIndices]);

  // --- Effect: Validate and Auto-Select Columns ---
  useEffect(() => {
    if (mergedColumns.length === 0) return;

    // Check if current selection is valid against new merged columns
    const currentSelection = Array.from(selectedColumns);
    const validSelection = currentSelection.filter(col => mergedColumns.includes(col));

    // If the data structure changed significantly (e.g. adding a join prefixes columns), 
    // and we lost selections, reset to Select All to prevent empty data.
    if (validSelection.length === 0 && mergedColumns.length > 0) {
        setSelectedColumns(new Set(mergedColumns));
    } else if (selectedColumns.size === 0) {
        // Initial selection
        setSelectedColumns(new Set(mergedColumns));
    }
  }, [mergedColumns]);


  const toggleColumn = (col: string) => {
    const newSet = new Set(selectedColumns);
    if (newSet.has(col)) {
      newSet.delete(col);
    } else {
      newSet.add(col);
    }
    setSelectedColumns(newSet);
  };

  const handleFinalize = () => {
    // Ensure we only use valid columns that actually exist in the data
    const validColumns = [...selectedColumns].filter(col => mergedColumns.includes(col));

    if (validColumns.length === 0) {
      alert("Please select at least one column.");
      return;
    }

    const processedData: ProcessedRow[] = [];
    const numericCols = new Set<string>();
    const categoricalCols = new Set<string>();

    // Sample first 100 rows to determine type
    const sampleSize = Math.min(mergedData.length, 100);
    const typeMap: {[key: string]: 'number' | 'string'} = {};
    
    validColumns.forEach(col => {
        let numericCount = 0;
        for(let i=0; i<sampleSize; i++) {
            const val = mergedData[i][col];
            if (val !== '' && val !== null && !isNaN(Number(val))) {
                numericCount++;
            }
        }
        // If > 80% are numbers, treat as number
        typeMap[col] = (numericCount / sampleSize) > 0.8 ? 'number' : 'string';
        if (typeMap[col] === 'number') numericCols.add(col);
        else categoricalCols.add(col);
    });

    mergedData.forEach(row => {
      const rowObj: ProcessedRow = {};
      validColumns.forEach(col => {
          const val = row[col];
          if (typeMap[col] === 'number') {
             rowObj[col] = val === '' || val === null ? 0 : Number(val);
          } else {
             rowObj[col] = val === null || val === undefined ? '' : String(val);
          }
      });
      processedData.push(rowObj);
    });

    const model: DataModel = {
      name: tables.map(t => t.name).join(' + '),
      data: processedData,
      columns: validColumns,
      numericColumns: [...numericCols],
      categoricalColumns: [...categoricalCols]
    };

    onFinalize(model);
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-200">
       {/* Header */}
       <header className="bg-slate-900/50 backdrop-blur-md border-b border-slate-800 px-8 py-4 flex justify-between items-center sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={onHome} className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition" title="Go Home">
             <Home className="w-5 h-5" />
          </button>
          <div className="w-px h-6 bg-slate-800 mx-1"></div>
          <div className="bg-indigo-500/20 p-2 rounded-lg border border-indigo-500/30">
            <Database className="text-indigo-400 w-5 h-5" />
          </div>
          <div>
             <h1 className="text-lg font-bold text-slate-100">Data Configuration</h1>
             <p className="text-xs text-slate-400">Configure tables, joins, and columns</p>
          </div>
        </div>

        <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button 
                onClick={() => setActiveTab('JOIN')}
                className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-2
                    ${activeTab === 'JOIN' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}
                `}
            >
                <LinkIcon className="w-3 h-3" /> Data Relationships
            </button>
            <button 
                 onClick={() => setActiveTab('COLUMNS')}
                 className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-2
                    ${activeTab === 'COLUMNS' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}
                `}
            >
                <Columns className="w-3 h-3" /> Select Columns
            </button>
        </div>

        <button 
            onClick={handleFinalize}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2 rounded-lg font-medium transition flex items-center gap-2 shadow-lg shadow-indigo-900/20 hover:shadow-indigo-500/20 active:scale-95"
        >
            Finalize & Analyze <ArrowRight className="w-4 h-4" />
        </button>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar: Tables & Settings */}
        <aside className="w-80 bg-slate-900 border-r border-slate-800 overflow-y-auto flex flex-col z-10 shadow-xl shrink-0">
            <div className="p-6 border-b border-slate-800">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                        <Table className="w-4 h-4 text-indigo-500" />
                        Tables ({tables.length})
                    </h3>
                    <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="text-indigo-400 hover:text-indigo-300 p-1 rounded hover:bg-indigo-500/10 transition"
                        title="Add another file (CSV/Excel)"
                    >
                        <Plus className="w-4 h-4" />
                    </button>
                    <input 
                        type="file" 
                        accept=".csv,.xlsx,.xls" 
                        ref={fileInputRef} 
                        className="hidden" 
                        onChange={(e) => e.target.files?.[0] && handleAddTable(e.target.files[0])}
                    />
                </div>
                
                <div className="space-y-3">
                    {tables.map(table => (
                        <div key={table.id} className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
                            <div className="flex items-center justify-between mb-2">
                                <span className="text-sm font-bold text-slate-200 truncate w-40" title={table.name}>{table.name}</span>
                                {tables.length > 1 && (
                                    <button onClick={() => setTables(tables.filter(t => t.id !== table.id))} className="text-slate-500 hover:text-red-400">
                                        <Trash2 className="w-3 h-3" />
                                    </button>
                                )}
                            </div>
                            <div className="flex items-center gap-2 bg-slate-900/50 p-1.5 rounded border border-slate-800">
                                <span className="text-[10px] text-slate-500 uppercase whitespace-nowrap">Header Row:</span>
                                <input 
                                    type="number" 
                                    min="0"
                                    value={headerIndices[table.id] ?? 0}
                                    onChange={(e) => setHeaderIndices({...headerIndices, [table.id]: parseInt(e.target.value) || 0})}
                                    className="w-full bg-transparent text-right text-xs text-indigo-300 focus:outline-none"
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {activeTab === 'COLUMNS' && (
                <div className="flex-1 p-6">
                    <div className="flex justify-between items-center mb-4">
                         <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                            <CheckSquare className="w-4 h-4 text-indigo-500" />
                            Selected ({selectedColumns.size})
                        </h3>
                        <button 
                            onClick={() => setSelectedColumns(new Set(mergedColumns))}
                            className="text-[10px] text-indigo-400 hover:text-indigo-300"
                        >
                            Select All
                        </button>
                    </div>
                   
                    <div className="space-y-1">
                        {mergedColumns.map((col, idx) => {
                            const isSelected = selectedColumns.has(col);
                            return (
                                <div 
                                    key={`${col}-${idx}`}
                                    onClick={() => toggleColumn(col)}
                                    className={`group flex items-center gap-3 p-2.5 rounded-lg cursor-pointer transition-all select-none border
                                        ${isSelected 
                                            ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-200' 
                                            : 'bg-transparent border-transparent hover:bg-slate-800 text-slate-500 hover:text-slate-300'
                                        }
                                    `}
                                >
                                    {isSelected 
                                        ? <CheckSquare className="w-4 h-4 text-indigo-400 shrink-0" /> 
                                        : <Square className="w-4 h-4 text-slate-600 group-hover:text-slate-400 shrink-0" />
                                    }
                                    <span className="text-sm font-medium truncate" title={col}>{col}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-8 overflow-hidden flex flex-col bg-slate-950">
            
            {activeTab === 'JOIN' && (
                <div className="flex-1 flex flex-col gap-8 overflow-y-auto custom-scrollbar pb-20">
                    <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
                        <div className="flex justify-between items-center mb-6">
                            <div>
                                <h2 className="text-lg font-bold text-white">Join Configuration</h2>
                                <p className="text-sm text-slate-400">Connect multiple tables to create a unified dataset.</p>
                            </div>
                            <button 
                                onClick={addJoin}
                                disabled={tables.length < 2}
                                className="bg-indigo-600 disabled:bg-slate-800 disabled:text-slate-600 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition"
                            >
                                <Plus className="w-4 h-4" /> Add Join
                            </button>
                        </div>

                        {tables.length < 2 && (
                             <div className="p-12 border-2 border-dashed border-slate-800 rounded-xl bg-slate-900/50 text-center">
                                <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                                    <Settings2 className="w-8 h-8 text-slate-500" />
                                </div>
                                <h3 className="text-slate-200 font-medium text-lg">Single Table Mode</h3>
                                <p className="text-slate-500 mt-2 max-w-md mx-auto">
                                    You currently have one table. The entire dataset will be used. 
                                    To merge data, upload another CSV or Excel file using the <span className="text-indigo-400">+</span> button in the sidebar.
                                </p>
                            </div>
                        )}

                        <div className="space-y-4">
                            {joins.map((join, index) => {
                                const leftTable = tables.find(t => t.id === join.leftTableId);
                                const rightTable = tables.find(t => t.id === join.rightTableId);
                                const leftCols = leftTable ? getTableColumns(leftTable.id) : [];
                                const rightCols = rightTable ? getTableColumns(rightTable.id) : [];

                                return (
                                    <div key={join.id} className="bg-slate-800/40 border border-slate-700 p-4 rounded-lg animate-fade-in-up">
                                        <div className="flex justify-between items-center mb-4">
                                            <span className="text-xs font-bold text-slate-500 uppercase">Join #{index + 1}</span>
                                            <button onClick={() => removeJoin(join.id)} className="text-slate-500 hover:text-red-400">
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
                                            {/* Left Table Config */}
                                            <div className="md:col-span-2 space-y-2">
                                                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                                                    <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Left Table</label>
                                                    <select 
                                                        value={join.leftTableId}
                                                        onChange={(e) => updateJoin(join.id, 'leftTableId', e.target.value)}
                                                        className="w-full bg-transparent text-sm text-white outline-none cursor-pointer"
                                                    >
                                                        {tables.map(t => <option key={t.id} value={t.id} className="text-slate-900">{t.name}</option>)}
                                                    </select>
                                                </div>
                                                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                                                     <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Key Column</label>
                                                     <select 
                                                        value={join.leftKey}
                                                        onChange={(e) => updateJoin(join.id, 'leftKey', e.target.value)}
                                                        className="w-full bg-transparent text-sm text-indigo-300 outline-none cursor-pointer"
                                                    >
                                                        <option value="" className="text-slate-900">Select Column...</option>
                                                        {leftCols.map(c => <option key={c} value={c} className="text-slate-900">{c}</option>)}
                                                    </select>
                                                </div>
                                            </div>

                                            {/* Join Type */}
                                            <div className="flex justify-center">
                                                <div className="bg-slate-900 p-2 rounded-full border border-slate-700">
                                                    <select 
                                                        value={join.type}
                                                        onChange={(e) => updateJoin(join.id, 'type', e.target.value)}
                                                        className="bg-transparent text-xs font-bold text-white outline-none text-center cursor-pointer appearance-none w-20"
                                                    >
                                                        <option value={JoinType.INNER} className="text-slate-900">INNER</option>
                                                        <option value={JoinType.LEFT} className="text-slate-900">LEFT</option>
                                                        <option value={JoinType.RIGHT} className="text-slate-900">RIGHT</option>
                                                        <option value={JoinType.FULL} className="text-slate-900">FULL</option>
                                                    </select>
                                                </div>
                                            </div>

                                            {/* Right Table Config */}
                                            <div className="md:col-span-2 space-y-2">
                                                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                                                    <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Right Table</label>
                                                    <select 
                                                        value={join.rightTableId}
                                                        onChange={(e) => updateJoin(join.id, 'rightTableId', e.target.value)}
                                                        className="w-full bg-transparent text-sm text-white outline-none cursor-pointer"
                                                    >
                                                        {tables.map(t => <option key={t.id} value={t.id} className="text-slate-900">{t.name}</option>)}
                                                    </select>
                                                </div>
                                                <div className="bg-slate-900 p-3 rounded border border-slate-800">
                                                     <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Key Column</label>
                                                     <select 
                                                        value={join.rightKey}
                                                        onChange={(e) => updateJoin(join.id, 'rightKey', e.target.value)}
                                                        className="w-full bg-transparent text-sm text-indigo-300 outline-none cursor-pointer"
                                                    >
                                                        <option value="" className="text-slate-900">Select Column...</option>
                                                        {rightCols.map(c => <option key={c} value={c} className="text-slate-900">{c}</option>)}
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {/* Preview Section for Joined Data */}
                    {mergedData.length > 0 && (
                        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
                            <h2 className="text-lg font-bold text-white mb-4">Merged Data Preview</h2>
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-sm text-slate-400">
                                    <thead className="bg-slate-950 uppercase text-xs font-semibold text-slate-500">
                                        <tr>
                                            {mergedColumns.slice(0, 8).map((col, i) => (
                                                <th key={i} className="px-4 py-3 whitespace-nowrap">{col}</th>
                                            ))}
                                            {mergedColumns.length > 8 && <th className="px-4 py-3">...</th>}
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-800">
                                        {mergedData.slice(0, 5).map((row, i) => (
                                            <tr key={i} className="hover:bg-slate-800/50">
                                                {mergedColumns.slice(0, 8).map((col, j) => (
                                                    <td key={j} className="px-4 py-3 whitespace-nowrap overflow-hidden max-w-[150px] truncate">
                                                        {row[col] !== null && row[col] !== undefined ? String(row[col]) : <span className="text-slate-600 italic">null</span>}
                                                    </td>
                                                ))}
                                                {mergedColumns.length > 8 && <td className="px-4 py-3 text-slate-600">...</td>}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'COLUMNS' && (
                 <div className="flex-1 flex flex-col items-center justify-center text-center p-12 text-slate-500">
                    <CheckSquare className="w-16 h-16 text-slate-700 mb-4" />
                    <h3 className="text-xl font-bold text-slate-300">Review Your Selection</h3>
                    <p className="max-w-md mt-2">
                        Use the sidebar to check or uncheck specific columns. 
                        Only selected columns will be analyzed by the AI for chart recommendations.
                    </p>
                    <div className="mt-8 grid grid-cols-2 gap-4 text-left max-w-2xl w-full">
                        <div className="bg-slate-900 p-4 rounded border border-slate-800">
                             <div className="text-xs text-slate-500 uppercase mb-1">Total Rows</div>
                             <div className="text-2xl font-bold text-white">{mergedData.length.toLocaleString()}</div>
                        </div>
                        <div className="bg-slate-900 p-4 rounded border border-slate-800">
                             <div className="text-xs text-slate-500 uppercase mb-1">Selected Columns</div>
                             <div className="text-2xl font-bold text-indigo-400">{selectedColumns.size} <span className="text-sm text-slate-500 font-normal">/ {mergedColumns.length}</span></div>
                        </div>
                    </div>
                 </div>
            )}
        </main>
      </div>
    </div>
  );
};