import React, { useState, useRef } from 'react';
import { Upload, FileText, Clock, Settings, LayoutDashboard, Sparkles, ChevronRight, FileSpreadsheet, Trash2, FolderOpen, PlusCircle } from 'lucide-react';
import { SavedDashboard } from '../types';

interface LandingProps {
  onFileUpload: (file: File) => void;
  savedDashboards: SavedDashboard[];
  onLoadDashboard: (dashboard: SavedDashboard) => void;
  onDeleteDashboard: (id: string) => void;
}

export const Landing: React.FC<LandingProps> = ({ onFileUpload, savedDashboards, onLoadDashboard, onDeleteDashboard }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [activeTab, setActiveTab] = useState<'NEW' | 'SAVED'>('NEW');

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFile = (file: File) => {
    const validTypes = ['text/csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
    if (validTypes.includes(file.type) || file.name.endsWith('.csv') || file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
      onFileUpload(file);
    } else {
      alert("Please upload a valid CSV or Excel file.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="px-8 py-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-indigo-500 to-violet-600 p-2.5 rounded-xl shadow-lg shadow-indigo-500/20">
            <LayoutDashboard className="text-white w-6 h-6" />
          </div>
          <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
            InsightAI
          </h1>
        </div>
        <button className="p-2 text-slate-400 hover:text-white transition hover:rotate-90 duration-300">
          <Settings className="w-6 h-6" />
        </button>
      </header>

      <main className="flex-1 p-8 max-w-7xl mx-auto w-full flex flex-col">
        
        {/* Tabs */}
        <div className="flex justify-center mb-12">
          <div className="bg-slate-900 p-1.5 rounded-2xl border border-slate-800 inline-flex">
            <button 
              onClick={() => setActiveTab('NEW')}
              className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2
                ${activeTab === 'NEW' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50' : 'text-slate-400 hover:text-white'}
              `}
            >
              <PlusCircle className="w-4 h-4" /> New Analysis
            </button>
            <button 
              onClick={() => setActiveTab('SAVED')}
              className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2
                ${activeTab === 'SAVED' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50' : 'text-slate-400 hover:text-white'}
              `}
            >
              <FolderOpen className="w-4 h-4" /> My Dashboards
            </button>
          </div>
        </div>

        {activeTab === 'NEW' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center animate-fade-in">
            {/* Left: Upload Section */}
            <div className="flex flex-col gap-8">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm font-medium mb-6">
                  <Sparkles className="w-4 h-4" />
                  <span>Powered by Gemini 2.0 Flash</span>
                </div>
                <h2 className="text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
                  Data to Dashboard <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-violet-400">
                    in seconds.
                  </span>
                </h2>
                <p className="text-lg text-slate-400 max-w-lg leading-relaxed">
                  Upload your raw CSV or Excel data. Our AI analyzes relationships, suggests KPIs, and builds professional dashboards automatically.
                </p>
              </div>

              <div 
                className={`relative group border-2 border-dashed rounded-3xl p-12 flex flex-col items-center justify-center text-center transition-all duration-300 cursor-pointer
                  ${isDragging 
                    ? 'border-indigo-400 bg-indigo-500/10 scale-[1.02]' 
                    : 'border-slate-700 bg-slate-900/50 hover:border-indigo-500/50 hover:bg-slate-800/80'
                  }
                `}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <input 
                  type="file" 
                  accept=".csv,.xlsx,.xls" 
                  ref={fileInputRef} 
                  className="hidden" 
                  onChange={(e) => e.target.files && handleFile(e.target.files[0])}
                />
                
                <div className={`bg-slate-800 p-5 rounded-2xl mb-6 shadow-xl transition-transform duration-300 ${isDragging ? 'scale-110 rotate-3' : 'group-hover:scale-110 group-hover:-rotate-3'}`}>
                  {isDragging ? (
                    <Upload className="w-10 h-10 text-indigo-400" />
                  ) : (
                    <FileSpreadsheet className="w-10 h-10 text-slate-300" />
                  )}
                </div>
                
                <h3 className="text-xl font-semibold text-white mb-2">Upload Dataset</h3>
                <p className="text-slate-500 text-sm">CSV or Excel files up to 10MB</p>
                
                {/* Decorative glow */}
                <div className="absolute inset-0 bg-indigo-500/5 blur-3xl -z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl" />
              </div>
            </div>

            {/* Right: Illustration / Steps */}
            <div className="relative hidden lg:block">
              {/* Glass card effect */}
              <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/10 to-transparent rounded-3xl blur-xl" />
              
              <div className="relative bg-slate-900/80 backdrop-blur-xl rounded-3xl border border-slate-800 p-10 shadow-2xl">
                  <h3 className="text-lg font-semibold text-white mb-8">How it works</h3>
                  <div className="space-y-8 relative">
                      <div className="absolute left-6 top-4 bottom-4 w-0.5 bg-slate-800"></div>
                      
                      {[
                        { title: "Upload Data", desc: "Supports multiple CSV & Excel files", icon: FileSpreadsheet },
                        { title: "Configure & Join", desc: "Merge tables and select key columns", icon: Settings },
                        { title: "AI Analysis", desc: "Gemini suggests relevant charts", icon: Sparkles },
                        { title: "Interact & Export", desc: "Filter, zoom, and save as PDF", icon: LayoutDashboard }
                      ].map((step, idx) => (
                        <div key={idx} className="relative flex items-start gap-6 group">
                            <div className="relative z-10 w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center group-hover:border-indigo-500/50 group-hover:bg-indigo-500/10 transition-colors">
                                <step.icon className="w-5 h-5 text-slate-400 group-hover:text-indigo-400" />
                            </div>
                            <div>
                                <h4 className="text-white font-medium text-lg group-hover:text-indigo-300 transition">{step.title}</h4>
                                <p className="text-slate-500 text-sm">{step.desc}</p>
                            </div>
                        </div>
                      ))}
                  </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'SAVED' && (
           <div className="animate-fade-in">
              {savedDashboards.length === 0 ? (
                 <div className="flex flex-col items-center justify-center py-20 border-2 border-dashed border-slate-800 rounded-3xl bg-slate-900/30">
                    <FolderOpen className="w-16 h-16 text-slate-700 mb-4" />
                    <h3 className="text-xl font-bold text-white">No Saved Dashboards</h3>
                    <p className="text-slate-500 mt-2 mb-6">You haven't saved any projects yet.</p>
                    <button 
                      onClick={() => setActiveTab('NEW')}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2 rounded-lg font-medium transition"
                    >
                      Start New Analysis
                    </button>
                 </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {savedDashboards.map((dash, idx) => (
                        <div 
                          key={dash.id} 
                          className="group bg-slate-900 border border-slate-800 rounded-2xl p-6 hover:border-indigo-500/50 hover:shadow-lg hover:shadow-indigo-900/20 transition-all cursor-pointer relative"
                          onClick={() => onLoadDashboard(dash)}
                        >
                           <div className="flex justify-between items-start mb-4">
                              <div className="p-3 bg-indigo-500/10 rounded-xl">
                                 <FileText className="w-6 h-6 text-indigo-400" />
                              </div>
                              <button 
                                onClick={(e) => { e.stopPropagation(); onDeleteDashboard(dash.id); }}
                                className="p-2 text-slate-600 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                           </div>
                           
                           <h3 className="text-lg font-bold text-white mb-1 group-hover:text-indigo-400 transition">{dash.name}</h3>
                           <div className="flex items-center gap-2 text-slate-500 text-sm mb-6">
                              <Clock className="w-3 h-3" />
                              <span>{dash.date}</span>
                           </div>

                           <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                              <span className="text-xs font-medium text-slate-400 bg-slate-950 px-2 py-1 rounded">
                                {dash.chartConfigs.length} Charts
                              </span>
                              <div className="flex items-center gap-1 text-indigo-400 text-sm font-medium">
                                 Open <ChevronRight className="w-4 h-4" />
                              </div>
                           </div>
                        </div>
                    ))}
                </div>
              )}
           </div>
        )}

      </main>
    </div>
  );
};